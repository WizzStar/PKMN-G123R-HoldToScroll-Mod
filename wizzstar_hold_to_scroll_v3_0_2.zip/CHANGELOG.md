# Changelog

Format: [keep a changelog](https://keepachangelog.com/en/1.1.0/).
Version headings match `manifest.json`'s `version`.

## 3.0.2

### Added

- **HOLD DELAY** and **REPEAT SPEED** run on real time (fast-forward proof): with fast-forward on (any GAME SPEED above 1X), held D-pad repeats at the same pace as at normal speed instead of speeding up with the game. Gen 1 / Gen 2 list menus are re-timed live if the speed changes while one is open.

### Changed

- Display name is now **G123R HoldToScroll Mod** (formerly G123R HoldToScrollUI Mod, then G123R Turbo_Scroll Mod; manifest id unchanged: `hold_to_scroll_ui`).

## 3.0.1

### Added

- **Gen 3** support: FireRed, LeafGreen, Ruby, Sapphire and Emerald (`"games": ["gen1", "gen2", "gen3"]`).
- Gen 3 hold-to-scroll in the party menu, bag / berry pouch / TM case, PC boxes, item storage and mail, Pokédex, shops, options, script multichoice lists, and the bag / party opened from battle.
- Gen 3 denylist: slot machines, roulette, Berry Blender, contests, Whiteout Rush, and cutscene layers.

### Changed

- Display name is now **G123R Turbo_Scroll Mod** (formerly G123R HoldToScrollUI Mod; manifest id unchanged: `hold_to_scroll_ui`).
- Battle command box (FIGHT / BAG / POKéMON / RUN) and YES/NO prompts are now suppressed on every generation, not just move select.
- Gen 3 menus with their own 40/5-frame repeat now follow HOLD DELAY / REPEAT SPEED.

### Fixed

- Menu detection, `isDown` and synthetic presses run under `pcall`. An engine change or missing input method now turns auto-repeat off for that frame instead of throwing from `input.step`.

## 1.0.4

### Changed

- Display name is now **G1R HoldToScrollUI Mod** (manifest id unchanged: `hold_to_scroll_ui`).

## 1.0.3

### Fixed

- Holding **Right** on HOLD DELAY / REPEAT SPEED no longer runaway-fires. Delay and rate are snapshotted when a hold starts, so Left/Right match Up/Down list scroll timing even while those options change under your thumb.

## 1.0.2

### Added

- Hold **Left** / **Right** also auto-repeats in menus (options rows, value steppers, etc.), with the same delay/speed as Up/Down. Still UI-only.

## 1.0.1

### Changed

- **REPEAT SPEED** is now a **1–5** choice (default **3**), not a raw frame number.
- Speed **3** uses the tuned **10-frame** cadence; 1/2 are slightly slower (14 / 12), 4/5 slightly faster (8 / 6).

## 1.0.0

### Added

- Hold **Up** / **Down** in menus to auto-scroll after a short delay.
- **AUTO SCROLL**, **HOLD DELAY**, and **REPEAT SPEED** mod options.
- `ui.list_menu` enablement so bag / shop / list UIs use engine `keyRepeat`.
- `input.step` synthetic edges so Start menu, party, options, and other-mod screens that read `wasPressed` also repeat.
- Overworld gate: never repeats while `stack:top().isOverworld`.
- Opt-out via `noDpadRepeat` / `dpadRepeat = false`, screen-id denylist, and `mod.exports`.
